﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;


namespace Compx102H
{
  /// <summary>
  /// <para>Wind farm designer form for COMPX102-21H Assignment 1.</para>
  /// <para>This starting point implementation allows the user to click
  /// in a picture box to produce grey wind turbines. Your task is to
  /// extend it to produce different kinds of wind turbines and to edit 
  /// them in different ways.</para>
  /// <para>Please see the assignment handout for details. Also please
  /// look at the WindTurbine class, which contains several methods and
  /// properties that will help you to solve this assignment.</para>
  /// <para>Written by Robi Malik, 2020-2021.</para>
  /// </summary>
  public partial class WindFarmForm : Form
  {
    //####################################################################
    //# Instance Variables
    /// <summary>
    /// List of all the turbines currently in the wind farm.
    /// </summary>
    private List<WindTurbine> _turbines;


    //####################################################################
    //# Constructor
    public WindFarmForm()
    {
      _turbines = new List<WindTurbine>();
      InitializeComponent();
    }


    //####################################################################
    //# Auxiliary Methods
    /// <summary>
    /// Displays all the wind turbines in the given graphics context.
    /// </summary>
    private void Draw(Graphics paper)
    {
      foreach (WindTurbine turbine in _turbines) {
        turbine.Draw(paper);
      }
    }


    //####################################################################
    //# Event Handlers
    /// <summary>
    /// Event handler called when the form needs redrawing.
    /// Causes all the wind turbines to be re-displayed.
    /// You do not need to change this method.
    /// </summary>
    private void PictureBoxWindFarmPaint(object sender, PaintEventArgs e)
    {
      Graphics paper = e.Graphics;
      Draw(paper);
    }

    /// <summary>
    /// Mouse-click handler of the picture box.
    /// You need to change this method.
    /// </summary>
    private void PictureBoxWindFarmMouseClick(object sender, MouseEventArgs e)
    {
      // Read mouse-click position
      int x = e.X;
      int y = e.Y;
      // Create wind turbine at this position, using "grey" default for attributes
      WindTurbine turbine = new WindTurbine(100, 0.5f, 4, false, Color.Gray, Color.LightGray, 2.5m, x, y);
      // Add wind turbine to farm list
      _turbines.Add(turbine);
      // Force redraw of the picture box to show changes
      _pictureBoxWindFarm.Refresh();
    }

    /// <summary>
    /// Tick event handler of animation timer.
    /// This method is called 50 times per second. 
    /// It rotates the rotors of all wind turbines slightly and redraws the picture box,
    /// producing the impression of rotating wind turbines.
    /// You do not need to change this method.
    /// </summary>
    private void AnimationTimerTick(object sender, EventArgs e)
    {
      // Rotate each rotor by 5 degrees
      foreach (WindTurbine turbine in _turbines) {
        turbine.Rotate(5.0f);
      }
      // Force redraw of the picture box to show changes
      _pictureBoxWindFarm.Refresh();
    }
  }
}
