﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PracticalTest3
{
    public partial class Form1 : Form
    {
        //Name:
        //Id:

        //The number of columns in the grid
        const int NUM_COLUMNS = 26;
        //The number of rows in the grid
        const int NUM_ROWS = 26;
        //The size of each quadrant in the grid
        const int QUADRANT_SIZE = 20;
        //Colors for the various terrain tiles
        Color QUADRANT_COLOR = Color.Black;
        Color SPIRAL_GALAXY_COLOR = Color.Purple;
        Color ELLIPTICAL_GALAXY_COLOR = Color.Orange;
        Color IRREGULAR_GALAXY_COLOR = Color.Yellow;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Converts the letter that represents a row into
        /// a y position in the grid.
        /// </summary>
        /// <param name="row">Letter of the row</param>
        /// <returns>The y position of the row in the grid</returns>
        private int CalcYPos(string row)
        {
            int y = (row[0] - 'A') * QUADRANT_SIZE;

            return y;
        }
        
        /// <summary>
        /// Display a qudrant in the grid at the given x and y position in
        /// the given colour.
        /// </summary>
        /// <param name="paper">Where to draw the tile</param>
        /// <param name="x">The x position of the tile</param>
        /// <param name="y">The y position of the tile</param>
        /// <param name="quadrantColor">The colour of the quadrant</param>
        private void DisplayQuadrant(Graphics paper, int x, int y, Color quadrantColor)
        {
            SolidBrush br = new SolidBrush(quadrantColor);
            Pen pen1 = new Pen(Color.White, 1);
            paper.FillRectangle(br, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
            paper.DrawRectangle(pen1, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
        }

        /// <summary>
        /// Display the galaxy at the given x and y value in the given colour.
        /// </summary>
        /// <param name="paper">Where to draw the weapon</param>
        /// <param name="x">The x position of the weapon</param>
        /// <param name="y">The y position of the weapon</param>
        /// <param name="galaxyColor">The colour of the galaxy</param>
        private void DisplayGalaxy(Graphics paper, int x, int y, Color galaxyColor)
        {
            SolidBrush br = new SolidBrush(galaxyColor);

            //Draw the quadrant
            DisplayQuadrant(paper, x, y, QUADRANT_COLOR);
            
            //Draw the galaxy inside the quadrant
            paper.FillEllipse(br, x, y, QUADRANT_SIZE, QUADRANT_SIZE);
        }

        /// <summary>
        /// Display the grid of quadrants.
        /// </summary>
        /// <param name="paper">Where to draw the grid</param>
        private void DisplayGrid(Graphics paper)
        {
            //x and y position of the current quadrant
            int x = 0;
            int y = 0;
            //For each row of quadrants to draw
            for (int row = 1; row <= NUM_ROWS; row++)
            {
                //For each quadrant to draw in the current row
                for (int col = 1; col <= NUM_COLUMNS; col++)
                {
                    //Draw the quadrant at the current x and y position
                    DisplayQuadrant(paper, x, y, QUADRANT_COLOR);
                    //Shift x to the right by width of quadrant
                    x += QUADRANT_SIZE;
                }
                //Shift y down by height of quadrant
                y += QUADRANT_SIZE;
                //Shift x back to start of row
                x = 0;
            }
        }

        
    }
}
